// Write your JavaScript code in this file and then open index.html in your browser.
